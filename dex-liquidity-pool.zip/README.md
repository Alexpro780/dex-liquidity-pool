# dex-liquidity-pool

A starter template for an automated market maker (AMM) style DEX liquidity pool contract using Hardhat.

## Features
- Simple x * y = k style pool stub
- Hardhat configuration
- Deployment script template

## Tech Stack
- Solidity
- Hardhat
- Node.js
